library(shiny)
library(googleVis)
library(dplyr)
library(stringr)
library(DT)
shinyServer(function(input, output){
  
  map_data <- reactive({
    print (as.numeric(input$Publish_Year/100))
    new %>%
      filter(century<= as.integer(input$Publish_Year/100)+1 & century>= as.integer(input$Publish_Year/100))%>%
      select(c(lon,lat, country, count))
  })
  
  map_reactive <- reactive({
    print (map_data())
    gvisGeoChart(data = map_data(),
                 locationvar = 'country', colorvar = 'count',
                 options=list(
                   width = 'auto', height = 'auto',
                   colorAxis = color_axis
                 )
    )
  })
  
  output$map_motion <- renderGvis({

    map_reactive()
  })# end of generating map
  
  #generate interactive dataset for recommendation
  rec_data = reactive({
    data_rating %>%
      filter(period %in% input$period & type %in% input$type & country %in% input$country)%>%
      select(book.image)
  })
  
  #generate images for recommendation
  output$rec_pic1 <- renderText({
    c('<img src="',as.character(rec_data()$book.image[1]),'" width = "150" >')
  })
  output$rec_pic2 <- renderText({
    c('<img src="',as.character(rec_data()$book.image[2]),'" width = "150" >')
  })
  output$rec_pic3 <- renderText({
    c('<img src="',as.character(rec_data()$book.image[3]),'" width = "150" >')
  })
  
  
  

  
  
  
})