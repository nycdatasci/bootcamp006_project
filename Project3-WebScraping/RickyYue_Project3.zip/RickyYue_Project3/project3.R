library(dplyr)

setwd("C:/Users/ricky/Dropbox/bootcamp/project3/cardpool")
file_names <- dir("C:/Users/ricky/Dropbox/bootcamp/project3/cardpool") # path to csv files

## function to append scraping hour extracted from the file name to dataframe
add_file_name = function(file_name){
  df = read.csv(file_name)
  df$opt_hour = strsplit(file_name,'_')[[1]][1]
  return (df)
}

## add all dataframes together
data_merged <- do.call(rbind,lapply(file_names,add_file_name)) # bind the together

data_merged$time=strsplit(toString(data_merged$time),"\\.")[[1]][1] ## remove the time scale smalled than second

## build a function to remove leading and trailing whitespaces from a string
trim <- function(x) {
  gsub("(^[[:space:]]+|[[:space:]]+$)", "", x)
}

data_merged$merchant = trim(data_merged$merchant)

##write a temp file
##write.csv(data_merged, "C:/Users/ricky/Dropbox/bootcamp/project3/cardpool/sat.csv")


cat_list = read.csv("C:/Users/ricky/Dropbox/bootcamp/project3/cardpool.csv") ##  get the dataframe with merchant name and category
cat_list = cat_list[,-c(1,3,5)]   ## remove columns not needed
cat_list$merchant = trim(cat_list$merchant)   ## remove heading and tailing whitespace
cat_list$category = as.character(cat_list$category) ##  define category as character

## correct a category name
cat_list$category = ifelse(cat_list$category=="Flowers &","Flowers & Gifts",cat_list$category)

## join the dataframe with category name
df = inner_join(data_merged,cat_list,by="merchant")
df = df[,-1] ## further clean the dataframe

df$opt_hour = as.factor(df$opt_hour) ## define opt_hour as factor 
