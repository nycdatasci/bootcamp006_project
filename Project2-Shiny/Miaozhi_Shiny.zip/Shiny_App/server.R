library('ggmap')
library('mapproj')
library('leaflet')
library('shiny')
library('ggplot2')
# source('global.R')
library(dygraphs)

#outputs  
shinyServer(function(input,output){
  output$map <- renderLeaflet({

      df = data.frame(lon = final[final$BEDS == input$select & 
                                            final$BATHS ==input$select2 & 
                                    final$area %in% input$Area &
                                    final$NEIGHBORHOOD %in% input$checkGroup&
                                    final$PRICE<input$range,]$lon,
                      lat = final[final$BEDS == input$select & 
                                    final$BATHS ==input$select2 &
                                    final$area %in% input$Area &
                                    final$NEIGHBORHOOD %in% input$checkGroup&
                                    final$PRICE<input$range,]$lat)
      #print(input$checkGroup)
      if(nrow(df)==0){
        m <- leaflet(geoloc) %>%
          addTiles() %>%  # Add default OpenStreetMap map tiles
          addCircleMarkers(~lon, ~lat,
                           radius = 4,
                           stroke = FALSE, fillOpacity = 0.5)%>%
        setView(-73.97694,40.74554,zoom = 12)
       }else{
    m <- leaflet(df) %>%
      addTiles() %>%  # Add default OpenStreetMap map tiles
      addCircleMarkers(~lon, ~lat,
        radius = 4,
        stroke = FALSE, fillOpacity = 0.5
      )} #%>%
      })
  
   output$dygraph <- renderDygraph({
        if ('Midtown' %in% input$District){
          dygraph(Midtown)
        }
     if ('Brooklyn' %in% input$District){
       dygraph(Brooklyn)
     }
     if ('Downtown' %in% input$District){
       dygraph(Downtown)
     }
     if ('Financial District' %in% input$District){
       dygraph(Financial_District)
     }
     if ('Upper East Side' %in% input$District){
       dygraph(Upper_East_Side)
     }
     if ('Upper Manhattan' %in% input$District){
       dygraph(Upper_Manhattan)
     }
     if ('Upper West Side' %in% input$District){
       dygraph(Upper_West_Side)
     }
    })
})
  
