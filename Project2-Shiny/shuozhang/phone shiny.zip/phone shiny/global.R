library(dplyr)
library(wordcloud)
library(RColorBrewer)
library(shinythemes)

device_data=read.csv('./data/phonedata.csv', header=T, stringsAsFactors = F)
#str(device_data)
device_map=dplyr::filter(device_data, !is.na(longitude), !is.na(latitude), !is.na(group))%>%
  dplyr::filter(longitude>=73, longitude<136, latitude>=4, latitude<54)
#str(device_map)
top10 <- names(sort(table(device_map$phone_brand_English), decreasing = T))[1:10]
gender=unique(device_map$gender)
agegroup=c("F23-", "F24-26", "F27-28", "F29-32", "F33-42", "F43+", "M22-", "M23-26", "M27-28", "M29-31", "M32-38", "M39+")

table1=device_map%>%
  dplyr::group_by(phone_brand_English)%>%
  dplyr::summarise(n=n())%>%
  arrange(desc(n))

phoneprice=read.csv('./data/phoneprice.csv',header=T, stringsAsFactors = F)
phoneprice=head(phoneprice,4)

device_map%>%
  dplyr::group_by(phone_brand_English, gender) %>%
  dplyr::summarise(n=n()) %>%
  mutate(percent=n/sum(n))-> phone_bygender


app_data=read.csv('./data/appmap.csv', header=T, stringsAsFactors = F)
#str(app_data)

app_map=dplyr::filter(app_data, !is.na(longitude), !is.na(latitude), !is.na(group))%>%
  dplyr::filter(longitude>=73, longitude<136, latitude>=4, latitude<54)
#str(app_map)

top10APP <- names(sort(table(app_map$category), decreasing = T))[1:10]

table2=app_map%>%
  dplyr::group_by(category)%>%
  dplyr::summarise(n=n())%>%
  arrange(desc(n))

app_map%>%
  dplyr::group_by(category, gender) %>%
  dplyr::summarise(n=n()) %>%
  mutate(percent=n/sum(n))-> app_bygender

app_map%>%
  dplyr::group_by(category, phone_brand_English, gender, age) %>%
  dplyr::summarise(n=n()) -> app_byphone

app_map$is_active=as.character(app_map$is_active)
app_map %>%
dplyr::group_by(category, is_active) %>%
  dplyr::summarise(n=n())->app_byactive

app_map%>%
  dplyr::group_by(category, phone_brand_English)%>%
  dplyr::summarise(n=n())->app_bybrand

