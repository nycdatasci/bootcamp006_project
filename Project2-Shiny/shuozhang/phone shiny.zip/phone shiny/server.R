library(shiny)
library(dplyr)
library(leaflet)
library(ggplot2)
library(plotly)
library(googleVis)
library(wordcloud)
library(RColorBrewer)
library(shinythemes)

shinyServer(function(input, output){
  output$wordplot1 <- renderPlot({
    count1=filter(device_map, gender %in% input$select_gender,
                  age %in% input$select_age[1]:input$select_age[2])
    phonefreq=count(count1, phone_brand_English)
    wordcloud(words = phonefreq$phone_brand_English, 
              freq = phonefreq$n, scale=c(8,1),min.freq=1,
              max.words=Inf, random.order=FALSE, rot.per=.15, 
              colors=brewer.pal(8,"Dark2"))
  })
  output$wordplot2 <- renderPlot({
    count2=filter(app_map, gender %in% input$select_gender,
                  age %in% input$select_age[1]:input$select_age[2])
    appfreq=count(count2, category)
    wordcloud(words = appfreq$category, 
              freq = appfreq$n, scale=c(4,1),min.freq=1,
              max.words=Inf, random.order=FALSE, rot.per=.15, 
              colors=brewer.pal(8,"Dark2"))
  })
  output$phonemap <- renderLeaflet({
    table1=filter(device_map, phone_brand_English %in% input$select_brand,
                  gender %in% input$select_gender, age %in% input$select_age[1]:input$select_age[2])
    leaflet(table1) %>% 
      addTiles() %>% 
      addMarkers(clusterOptions = markerClusterOptions(), lat = ~ latitude, lng = ~ longitude, popup=~phone_brand_English) %>%
      setView(lng = 105, lat = 35, zoom = 4)
  })
  output$phoneplot1 <- renderPlotly({
    g1=ggplot(data=table1, aes(x=reorder(phone_brand_English,n), y=n,
                                              fill=phone_brand_English))+
      geom_bar(stat = 'identity')+
      xlab('')+
      ylab('Number of Users')+
      ggtitle('User Distribution of Top 10 Phone Brands')+
      scale_y_continuous(expand = c(0,0), limits = c(0,3000))+
      coord_flip()+
      theme_bw()+
      theme(legend.position="none", axis.text.y = element_text(angle = -35, hjust = 1))
  })
  

  output$phonems<- renderPlotly({
    gg=ggplot(data=phoneprice, aes(x=reorder(Vendor,X2015.MS), y=X2015.MS, fill=Vendor))+
      geom_bar(stat = 'identity', alpha=0.7)+
      xlab('')+
      ylab('Market Share of 2015')+
      ggtitle('Market Share of Top 4 Phone Brands in 2015')+
      scale_y_continuous(expand = c(0,0), limits = c(0,0.2))+
      coord_flip()+
      theme_bw()+
      theme(legend.position="none", axis.text.y = element_text(angle = -35, hjust = 1))
  })
  output$phoneplot2 <- renderPlotly({
    phone_bygender1=filter(phone_bygender, gender %in% input$select_gender)
    g2=ggplot(data=phone_bygender1, aes(x=reorder(phone_brand_English,n), y=n,
                                     fill=gender)) +
      geom_bar(stat = "identity", position="dodge",alpha=.7, color='white') +
      xlab("") +
      ylab("Number of Users") +
      ggtitle('Gender Distribution')+
      scale_y_continuous(expand = c(0,0))+
      coord_flip()+
      theme_bw()+
      theme(legend.title=element_blank(), axis.text.y = element_text(angle = -35, hjust = 1))
  })
  output$phoneplot3 <- renderPlotly({
    phone_bygender1=filter(phone_bygender, gender %in% input$select_gender)
    g3=ggplot(data=phone_bygender1, aes(x=phone_brand_English, y=percent,
                                        color= gender)) +
      geom_point() +
      geom_line()+
      xlab("") +
      ylab("Percent of Users") +
      ggtitle('Gender Percent Distribution')+
      scale_y_continuous(expand = c(0,0))+
      ylim(0,1)+
      coord_flip()+
      theme_bw()+
      theme(legend.title=element_blank(),axis.text.y = element_text(angle = -35, hjust = 1))
  })
  output$phoneplot4 <- renderPlotly({
    age_dis=filter(device_map, phone_brand_English %in% input$select_brand, age %in% input$select_age[1]:input$select_age[2] )
    g4=ggplot(data=age_dis, 
              aes(x=age, fill=phone_brand_English)) + 
      geom_histogram(size = 0.1,alpha=.7) + 
      ylab("Number of Users") + 
      xlim(10, 88)+
      ggtitle('Age Histogram Distribution')+
      facet_grid(gender~.) +
      theme_bw()+
      theme(legend.title=element_blank(), axis.text.y = element_text(angle = -35, hjust = 1))

  })
  output$phoneplot5 <- renderPlotly({
    age_dis1=filter(device_map, phone_brand_English %in% input$select_brand)
    g5=ggplot(data = age_dis1, aes(x=reorder(phone_brand_English, age),
                                y=age,color=phone_brand_English)) + 
      geom_boxplot(aes(group=phone_brand_English, color=phone_brand_English)) + 
      geom_jitter(alpha = .2, shape = 1, width = .5) + 
      xlab("") + ylab("age") + ggtitle('Age Boxplot Distribution')+
      facet_grid(gender~.)+
      theme_bw()+
      theme(legend.title=element_blank(), axis.text.y = element_text(angle = -35, hjust = 1))
  })
  output$appmap <- renderLeaflet({
    table2=filter(app_map, category %in% input$select_APP,
                  phone_brand_English %in% input$select_brand,
                  gender %in% input$select_gender,
                  age %in% input$select_age[1]:input$select_age[2])
    leaflet(table2) %>% 
      addTiles() %>% 
      addMarkers(clusterOptions = markerClusterOptions(), lat = ~ latitude, lng = ~ longitude, popup=~category) %>%
      setView(lng = 105, lat = 35, zoom = 4)
  })
  output$phoneplot6 <- renderPlotly({
    g6=ggplot(data=table2, aes(x=reorder(category,n), y=n,
                               fill=category))+
      geom_bar(stat = 'identity')+
      xlab('')+
      ylab('Number of Users')+
      ggtitle('User Distribution of Top 10 APPs')+
      scale_y_continuous(expand = c(0,0), limits = c(0,8000))+
      coord_flip()+
      theme_bw()+
      theme(legend.position="none")
  })
  output$phoneplot66 <- renderPlotly({
    app_bybrand1=filter(app_bybrand, phone_brand_English %in% input$select_brand)
    g66=ggplot(data=app_bybrand1, aes(x=reorder(category,n), y=n,
                               fill=phone_brand_English))+
      geom_bar(stat = 'identity', position='dodge', alpha=0.7, color='white')+
      xlab('')+
      ylab('Number of Users')+
      ggtitle('Top 10 APPs of Different Phone')+
      scale_y_continuous(expand = c(0,0), limits = c(0,1600))+
      coord_flip()+
      theme_bw()+
      theme(legend.title=element_blank())
  })
  output$phoneplot7 <- renderPlotly({
    app_bygender1=filter(app_bygender, gender %in% input$select_gender)
    g7=ggplot(data=app_bygender1, aes(x=reorder(category,n), y=n,
                                        fill = gender)) +
      geom_bar(stat = "identity", position="dodge",alpha=.7, color='white') +
      xlab("") +
      ylab("Number of Users") +
      ggtitle('Gender Distribution')+
      scale_y_continuous(expand = c(0,0), limits = c(0,6000))+
      coord_flip()+
      theme_bw()+
      theme(legend.title=element_blank())
  })
  output$phoneplot8 <- renderPlotly({
    app_bygender1=filter(app_bygender, gender %in% input$select_gender)
    g8=ggplot(data=app_bygender1, aes(x=category, y=percent,
                                        color = gender)) +
      geom_point() +
      geom_line()+
      xlab("") +
      ylab("Percent of Users") +
      ggtitle('Gender Percent Distribution')+
      scale_y_continuous(expand = c(0,0))+
      ylim(0,1)+
      coord_flip()+
      theme_bw()+
      theme(legend.title=element_blank())
  })
  output$phoneplot9 <- renderPlotly({
    appage_dis=filter(app_map, category %in% input$select_APP, age %in% input$select_age[1]:input$select_age[2] )
    g9=ggplot(data=appage_dis, 
              aes(x=age, fill=category)) + 
      geom_histogram(size = 0.1,alpha=.7) + 
      ylab("Number of Users") + 
      xlim(10, 88)+
      ggtitle('Age Histogram Distribution')+
      facet_grid(gender~.) +
      theme_bw()+
      theme(legend.title=element_blank())
    
  })
  output$phoneplot10 <- renderPlotly({
    appage_dis1=filter(app_map, category %in% input$select_APP)
    g10=ggplot(data = appage_dis1, aes(x=reorder(category, age),
                                   y=age,color=category)) + 
      geom_boxplot(aes(group=category, color=category)) + 
      geom_jitter(alpha = .2, shape = 1, width = .5) + 
      xlab("") + ylab("age") + ggtitle('Age Boxplot Distribution')+
      facet_grid(gender~.)+
      theme_bw()+
      theme(legend.title=element_blank())
  })
  output$phoneplot11 <- renderPlotly({
    app_byphone1=filter(app_byphone,phone_brand_English %in%input$select_brand, 
                        gender %in% input$select_gender,
                        age %in% input$select_age[1]:input$select_age[2])
    g11=ggplot(data=app_byphone1, aes(x=reorder(category,n), y=n,
                                      fill=category)) +
      geom_bar(stat = "identity") +
      xlab("") +
      ylab("Number of Users") +
      ggtitle('Phone Distribution')+
      scale_y_continuous(expand = c(0,0), limits = c(0,1500))+
      coord_flip()+
      theme_bw()+
      theme(legend.position="none")+
      theme(legend.title=element_blank())
  })
  output$phoneplot12 <- renderPlotly({
    g12=ggplot(data=app_byactive, aes(x=reorder(category,n), y=n,
                                      fill=is_active)) +
      geom_bar(stat = "identity", position="dodge", alpha=.7) +
      xlab("") +
      ylab("Number of Users") +
      ggtitle('Active App Distribution')+
      scale_y_continuous(expand = c(0,0), limits = c(0,6000))+
      coord_flip()+
      theme_bw()+
      theme(legend.title=element_blank())
  })

})