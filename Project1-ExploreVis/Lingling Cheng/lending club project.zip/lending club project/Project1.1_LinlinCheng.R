##Linlin Cheng
##Project I
#Personal Loan default analysis using 
#Lender's Club Data

#install.packages('dplyr')
#install.packages('ggplot2')
#install.packages('zoo')
#install.packages('lubridate)
#install.packages('plotrix')

library('dplyr')
library('ggplot2')
library('zoo')
library('lubridate')
library('plotrix')


#read data into Rstudio
loan <- read.csv("~/Downloads/loan.csv", row.names=1, stringsAsFactors=FALSE)

################################
#recode state names in the original file 
#"AK" "AL" "AR" "AZ" "CA" "CO" "CT" "DC" "DE" "FL" "GA" "HI"
#[13] "IA" "ID" "IL" "IN" "KS" "KY" "LA" "MA" "MD" "ME" "MI" "MN"
#[25] "MO" "MS" "MT" "NC" "ND" "NE" "NH" "NJ" "NM" "NV" "NY" "OH"
#[37] "OK" "OR" "PA" "RI" "SC" "SD" "TN" "TX" "UT" "VA" "VT" "WA"
#[49] "WI" "WV" "WY"

loan$addr_state[which(loan$addr_state=="AK")]<-"alaska"
loan$addr_state[which(loan$addr_state=="AL")]<-"alabama"
loan$addr_state[which(loan$addr_state=="AR")]<-"arkansas"
loan$addr_state[which(loan$addr_state=="AZ")]<-"arizona"
loan$addr_state[which(loan$addr_state=="CA")]<-"california"
loan$addr_state[which(loan$addr_state=="CO")]<-"colorado"
loan$addr_state[which(loan$addr_state=="CT")]<-"connecticut"
loan$addr_state[which(loan$addr_state=="DE")]<-"delaware"
loan$addr_state[which(loan$addr_state=="FL")]<-"florida"
loan$addr_state[which(loan$addr_state=="DC")]<-"district of columbia"
loan$addr_state[which(loan$addr_state=="GA")]<-"georgia"
loan$addr_state[which(loan$addr_state=="HI")]<-"hawaii"
loan$addr_state[which(loan$addr_state=="IA")]<-"iowa"
loan$addr_state[which(loan$addr_state=="ID")]<-"idaho"
loan$addr_state[which(loan$addr_state=="IL")]<-"illinois"
loan$addr_state[which(loan$addr_state=="IN")]<-"indiana"
loan$addr_state[which(loan$addr_state=="KS")]<-"kansas"
loan$addr_state[which(loan$addr_state=="KY")]<-"kentucky"
loan$addr_state[which(loan$addr_state=="LA")]<-"louisiana"
loan$addr_state[which(loan$addr_state=="MA")]<-"massachusetts"
loan$addr_state[which(loan$addr_state=="MD")]<-"maryland"
loan$addr_state[which(loan$addr_state=="ME")]<-"maine"
loan$addr_state[which(loan$addr_state=="MI")]<-"michigan"
loan$addr_state[which(loan$addr_state=="MN")]<-"minnesota"
loan$addr_state[which(loan$addr_state=="MO")]<-"missouri"
loan$addr_state[which(loan$addr_state=="MS")]<-"mississippi"
loan$addr_state[which(loan$addr_state=="MT")]<-"montana"
loan$addr_state[which(loan$addr_state=="NC")]<-"north carolina"
loan$addr_state[which(loan$addr_state=="ND")]<-"north carolina"
loan$addr_state[which(loan$addr_state=="NE")]<-"nebraska"
loan$addr_state[which(loan$addr_state=="NH")]<-"new hampshire"
loan$addr_state[which(loan$addr_state=="NJ")]<-"new jersey"
loan$addr_state[which(loan$addr_state=="NM")]<-"new mexico"
loan$addr_state[which(loan$addr_state=="NV")]<-"nevada"
loan$addr_state[which(loan$addr_state=="NY")]<-"new york"
loan$addr_state[which(loan$addr_state=="OH")]<-"ohio"
loan$addr_state[which(loan$addr_state=="OK")]<-"oklahoma"
loan$addr_state[which(loan$addr_state=="OR")]<-"oregon"
loan$addr_state[which(loan$addr_state=="PA")]<-"pennsylvania"
loan$addr_state[which(loan$addr_state=="RI")]<-"rhode island"
loan$addr_state[which(loan$addr_state=="SC")]<-"south carolina"
loan$addr_state[which(loan$addr_state=="SD")]<-"south dakota"
loan$addr_state[which(loan$addr_state=="TN")]<-"tennessee"
loan$addr_state[which(loan$addr_state=="TX")]<-"texas"
loan$addr_state[which(loan$addr_state=="UT")]<-"utah"
loan$addr_state[which(loan$addr_state=="VA")]<-"virginia"
loan$addr_state[which(loan$addr_state=="VT")]<-"vermont"
loan$addr_state[which(loan$addr_state=="WA")]<-"washington"
loan$addr_state[which(loan$addr_state=="WI")]<-"wisconsin"
loan$addr_state[which(loan$addr_state=="WV")]<-"west virginia"
loan$addr_state[which(loan$addr_state=="WY")]<-"wyoming"


#########################################
#Seperate data into two sub-datasets for
#for results realized loan observations as loan_old, 
#and unrealized observations as loan_new

loan_old<-filter(loan, loan_status=='Fully Paid' | loan_status=='Charged Off' | loan_status== 'Default')[,c(2:8,11:17,23:27, 30:44, 49, 51:52)]



##convert minor loan status with few observations into three categories

loan_old$loan_status<-ifelse(loan_old$loan_status== 'Charged Off', 'Default', loan_old$loan_status)

#compile homeownership status of outstaning loans:

loan_new<-filter(loan,loan_status == 'Current')[,c(2:8,11:17,23:27, 30:44,46, 49, 51:52)]

loan_new$home_ownership<-ifelse(loan_new$home_ownership=="ANY", "OTHER", ifelse(loan_new$home_ownership=="NONE", "OTHER", loan_new$home_ownership))

##########
#calculate the mean interest rate for loans issued each month 
st<-summarise(group_by(loan_old, issue_d), mean_interest=mean(int_rate))
stcount<-summarise(group_by(loan_old, issue_d), count=n())

#calculate the mean interest rate charged in each state
st1<-summarise(group_by(loan_old, addr_state), mean_interest=mean(int_rate))


#same procedure as above for mean default rate by states:
st2<-summarise(group_by(loan_old, addr_state), mean_default_rate=sum(loan_status=="Default")/length(loan_status))


####
st$issue_d<-as.yearmon(st$issue_d, "%b-%Y")
stcount$issue_d<-as.yearmon(stcount$issue_d, "%b-%Y")
#st <- arrange(t, issue_d)
#(1)
ggplot(st, aes(issue_d, mean_interest)) + geom_line() +
  xlab("") + ylab("Interest Rate") +ggtitle('Averge Interest Rate Charged Over Time')
#(2)
ggplot(stcount, aes(issue_d, count)) + geom_line() +
  xlab("") + ylab("")+ggtitle('Number of Approved Loans') 

#create a scatter plot of No. of loans vs. interest rates
sca<-data.frame(st$mean_interest,stcount$count)
#(3)
ggplot(data=sca,  aes(x = stcount.count, y = st.mean_interest))+geom_point()+
    geom_smooth(method='lm')+xlab('Number of Loans')+ylab('Interest Rate')+
    ggtitle('Interet Rate vs Number of Loans Approved')+annotate("text", x=7000, y=10, label= "correlation ≈ 0.80") 
cor(st$mean_interest,stcount$count) #[1] 0.8048114



####Plot of mean interest for each month
tmp<-data.frame(mean_interest=st$mean_interest, month=as.factor(month(st$issue_d))) 
tmp1<-summarise(group_by(tmp, month), mean_interest_month=mean(mean_interest))
m<-mean(tmp1$mean_interest_month)#12.67741
#(4)
ggplot(data = tmp1, aes(x =month, y = mean_interest_month))+ geom_point()+geom_hline(yintercept=12.67741, linetype=2)+
    xlab('Month')+ylab("Interest Rate")+ggtitle('Interest Rate by Month')+
    annotate("text", x=9, y=12.9, label= "Mean Interest Rate ≈ 12.68") 

###
loan_old$home_ownership<-ifelse(loan_old$home_ownership=="ANY", "OTHER", 
                                ifelse(loan_old$home_ownership=="NONE", "OTHER", loan_old$home_ownership))
loan_old$loan_status <- factor(loan_old$loan_status, levels = loan_old$loan_status[c(1,4,3,2)])
#(5)
#need to reorient, dodge bar charts
ggplot(data = loan_old, aes(x = loan_status)) + geom_bar(aes(fill = home_ownership), position="dodge")

#(6)
#filled bar chart for home ownership
cc2 <- ggplot(data = loan_old, aes(x = home_ownership)) +
  geom_bar(aes(fill = loan_status), position = "fill") #+ coord_polar(theta = "y")
cc2


#(7) Grade status

cc1 <- ggplot(data = loan_old, aes(x = grade)) +
  geom_bar(aes(fill = loan_status), position = "fill") #+ coord_polar(theta = "y")
cc1

############

#(8)interest rate charged in each state
us <- map_data("state")
gg <- ggplot()
gg <- gg + geom_map(data=us, map=us,
                    aes(x=long, y=lat, map_id=region),
                    fill="#ffffff", color="#ffffff", size=0.15)
gg <- gg + geom_map(data=st1, map=us,
                    aes(fill=mean_interest, map_id=addr_state),
                    color="#ffffff", size=0.15)+xlab('')+ylab('')+theme_bw()+ggtitle('Interest Rate by State')
gg

############
##(9) mean default rate in each state
gg1<-ggplot()+geom_map(data=us, map=us,
                       aes(x=long, y=lat, map_id=region),
                       fill="#ffffff", color="#ffffff", size=0.15)
gg1 <- gg1 + geom_map(data=st2, map=us,
                      aes(fill=mean_default_rate, map_id=addr_state),
                      size=0.15)
gg1 <- gg1 + scale_fill_continuous(low='white', high='darkred',
                                   guide='colorbar')+ geom_density2d()+theme_bw()+ggtitle('Default Rate by State')
gg1
####
#cal cor?
cor(st1$mean_interest, st2$mean_default_rate)  #[1] 0.4408346
defa<-data.frame(interest_rate=st1$mean_interest, default_rate=st2$mean_default_rate)
#(10) correlation scatter plot for interest rate/default rate
ggplot(defa, aes(interest_rate, default_rate))+geom_point()+geom_smooth(method='lm')+ggtitle('Default Rate vs Interest Rate')


############
#Modeling Part
fit3<-glm(as.factor(loan_old$loan_status)~annual_inc+funded_amnt+int_rate+installment+grade+home_ownership, data= loan_old, family = "binomial"(link="logit"))

#recode grade & home ownership
#convert grade, homeownership into factors
#fit3$formula
#as.factor(loan_old$loan_status) ~ annual_inc + funded_amnt + 
#  int_rate + installment + grade + home_ownership

loan_new$home_ownership<-ifelse(loan_new$home_ownership=="ANY", "OTHER", 
                                ifelse(loan_new$home_ownership=="NONE", "OTHER", loan_new$home_ownership))

loan_tmp<-loan_new[,c(10,2,5,6,7,9)]


gradeb<-ifelse(loan_tmp$grade=="B", 1, 0)
gradec<-ifelse(loan_tmp$grade=="C", 1, 0)
graded<-ifelse(loan_tmp$grade=="D", 1, 0)
gradee<-ifelse(loan_tmp$grade=="E", 1, 0)
gradef<-ifelse(loan_tmp$grade=="F", 1, 0)
gradeg<-ifelse(loan_tmp$grade=="G", 1, 0)

homeother<-ifelse(loan_tmp$home_ownership=="OTHER", 1, 0)
homeown<-ifelse(loan_tmp$home_ownership=="OWN", 1, 0)
homerent<-ifelse(loan_tmp$home_ownership=="RENT",1, 0)

one<-rep(1, length(homerent))

#bind corresponding factors into a matrix
newdata<-cbind(one, loan_tmp[,1:4], gradeb, gradec, graded, gradee, gradef, gradeg,homeother, homeown, homerent)
#beta matrix
beta<- fit3$coefficients

#Logistic Probability estimation 
prob<-1/(1+exp(-(as.matrix(newdata)%*%t(t(beta)))))

#calc expected loss amount(1), plot by state
balance<-(loan_new$loan_amnt-loan_new$last_pymnt_amnt)
e_loss<-(1-prob)*balance


#cal default rate(2) by state
balance_data<-data.frame(addr_state=loan_new$addr_state, prob, e_loss)
#calc loss by state=probability of default*amount outstanding
state_data<-summarise(group_by(balance_data, addr_state), expected_loss=sum(e_loss), default_rate=mean(1-prob))

###creating plots:
#Total loss sum preview, maybe just don't include this part
#change IOWA to NA, not allowing LC..
#(11)  
us <- map_data("state")

gg3 <- ggplot()+ggtitle("Expected Loss by State")+xlab("") + ylab("") +theme_bw()

gg3 <- gg3 + geom_map(data=us, map=us,
                      aes(x=long, y=lat, map_id=region),
                      fill="#ffffff", color="#ffffff", size=0.15)
gg3 <- gg3 + geom_map(data=state_data, map=us,
                      aes(fill=expected_loss, map_id=addr_state),
                      color="#ffffff", size=0.15)+  scale_fill_gradient(low="white", high="darkred")
gg3


