#### PACKAGES
```{r}
library(devtools)
library(h2o)
library(h2oEnsemble) # Requires version >=0.0.4 of h2oEnsemble
localH2O = h2o.init(ip = 'localhost', port = 54321,nthreads=-1,max_mem_size="12g") # Start an H2O cluster with nthreads = num cores on your machine
```

#### DATA
```{r}
train = h2o.importFile("train.final17.ames.csv")
test = h2o.importFile("test.final17.ames.csv")
id = test$Id
train = train[,c(-1,-2)]
#train$SalePrice = log(train$SalePrice)
test = test[,c(-1,-2)]
y = "SalePrice"
x = setdiff(names(train), y)
```

#### GRID SEARCH 
```{r}

#####GBM
gbm.grid <- h2o.grid("gbm", x = x, y = y, 
                 training_frame = train, nfolds = 5,
                 hyper_params = list(ntrees = c(20,50,100,400), max_depth = c(10,15,20), 
                                     learn_rate = c(0.05,0.1), min_rows = c(5,10,15)))

#Obtain Best Model
grid@summary_table[1,]
best_gbm_model <- h2o.getModel(grid@model_ids[[1]])

h2o.varimp(best_gbm_model)

h2o.varimp_plot(best_gbm_model)


################################################
data_split <- h2o.splitFrame(train, ratios = 0.8)

hyper_parameters <- list(alpha = c(0.1,0.2,0.3,0.4,0.5,0.6,0.7))
model_glm_grid <- h2o.grid(
  algorithm = "glm", 
  #hyper_params = hyper_parameters,
  training_frame = data_split[[1]], 
  validation_frame = data_split[[2]], 
  x = x, 
  y = y,
  #lambda_search = TRUE,
  #alpha = 0.3,
  family = "gamma",
  link = "log"
)

###########################################################
####### GLM
########################################################################################
gamma.glm <- h2o.glm(y = y, x = x, training_frame = train,                             #
                     nfolds = 5, alpha = seq(0,1,0.001),
                     family = "gamma", link = "log")#
########################################################################################


glm.grid <- h2o.grid("glm", x = x, y = y, 
                     training_frame = train, nfolds = 5, 
                     family = "gamma",link = "log",
                     hyper_params = hyper_parameters) 


hyper_parameters = list (lambda_search = TRUE,
                         nlambda = 10,
                         return_all_lambda = TRUE,
                         alpha = c(0, 0.25, 0.5, 0.75, 1),
                         nlambda=10,
                         lambda_search=T,
                         return_all_lambda=T
                         )

grid1000 <- h2o.glm (y = y , x = x , training_frame = train, nfolds = 5,
                   family = "gamma" , link = "log",nlambda=10,
                   lambda_search=T)



grid100@summary_table[1,]

best_glm_model <- h2o.getModel(glm.grid@model_ids[[1]])



gamma.glm <- h2o.glm(y = y, x = x, training_frame = train, 
                     nfolds = 5, alpha = seq(0,1,0.001),family = "gamma", link = "log")

##################################
alpha_opts = list(list(0), list(.25), list(.5), list(.75), list(1))
hyper_parameters = list(alpha = alpha_opts)
gamma.grid <- h2o.grid("glm", hyper_params = hyper_parameters,
                   y = y, x = x,
                   training_frame = train, 
                   family = "gamma",link = "log")





#####NEURAL NETWORK
hyper_params <- list(hidden=list(c(32,32,32),c(64,64), c(100,100)),
                     input_dropout_ratio=c(0,0.05),
                     rate=c(0.01,0.02),
                     rate_annealing=c(1e-8,1e-7,1e-6))


grid4 <- h2o.grid(algorithm="deeplearning",training_frame=train1, x=x, y=y, 
                  epochs=10, momentum_stable=0.9,momentum_ramp=1e7,
                  l1=1e-5, l2=1e-5, activation=c("Rectifier"),
                  max_w2=10,hyper_params=hyper_params, nfolds = 5)
#Obtain Best Model
grid4@summary_table[1,]
best_model <- h2o.getModel(grid4@model_ids[[1]])






```

##MODELS WRAPPERS
```{r}
h2o.glm.1 <- function(..., alpha = 0.0) h2o.glm.wrapper(..., alpha = alpha)
h2o.glm.2 <- function(..., alpha = 0.5) h2o.glm.wrapper(..., alpha = alpha)
h2o.glm.3 <- function(..., alpha = 1.0) h2o.glm.wrapper(..., alpha = alpha)

h2o.randomForest.1 <- function(..., ntrees = 200, nbins = 50, seed = 1) h2o.randomForest.wrapper(..., ntrees = ntrees, nbins = nbins, seed = seed)
h2o.randomForest.2 <- function(..., ntrees = 200, sample_rate = 0.75, seed = 1) h2o.randomForest.wrapper(..., ntrees = ntrees, sample_rate = sample_rate, seed = seed)
h2o.randomForest.3 <- function(..., ntrees = 200, sample_rate = 0.85, seed = 1) h2o.randomForest.wrapper(..., ntrees = ntrees, sample_rate = sample_rate, seed = seed)
h2o.randomForest.4 <- function(..., ntrees = 200, nbins = 50, balance_classes = TRUE, seed = 1) h2o.randomForest.wrapper(..., ntrees = ntrees, nbins = nbins, balance_classes = balance_classes, seed = seed)
h2o.gbm.1 <- function(..., ntrees = 100, seed = 1) h2o.gbm.wrapper(..., ntrees = ntrees, seed = seed)
h2o.gbm.2 <- function(..., ntrees = 100, nbins = 50, seed = 1) h2o.gbm.wrapper(..., ntrees = ntrees, nbins = nbins, seed = seed)
h2o.gbm.3 <- function(..., ntrees = 100, max_depth = 10, seed = 1) h2o.gbm.wrapper(..., ntrees = ntrees, max_depth = max_depth, seed = seed)
h2o.gbm.4 <- function(..., ntrees = 100, col_sample_rate = 0.8, seed = 1) h2o.gbm.wrapper(..., ntrees = ntrees, col_sample_rate = col_sample_rate, seed = seed)
h2o.gbm.5 <- function(..., ntrees = 100, col_sample_rate = 0.7, seed = 1) h2o.gbm.wrapper(..., ntrees = ntrees, col_sample_rate = col_sample_rate, seed = seed)
h2o.gbm.6 <- function(..., ntrees = 100, col_sample_rate = 0.6, seed = 1) h2o.gbm.wrapper(..., ntrees = ntrees, col_sample_rate = col_sample_rate, seed = seed)
h2o.gbm.7 <- function(..., ntrees = 100, balance_classes = TRUE, seed = 1) h2o.gbm.wrapper(..., ntrees = ntrees, balance_classes = balance_classes, seed = seed)
h2o.gbm.8 <- function(..., ntrees = 100, max_depth = 3, seed = 1) h2o.gbm.wrapper(..., ntrees = ntrees, max_depth = max_depth, seed = seed)
h2o.deeplearning.1 <- function(..., hidden = c(500,500), activation = "Rectifier", epochs = 50, seed = 1)  h2o.deeplearning.wrapper(..., hidden = hidden, activation = activation, seed = seed)
h2o.deeplearning.meta <- function(..., hidden = c(500,500), activation = "Tanh", epochs = 50, seed = 1)  h2o.deeplearning.wrapper(..., hidden = hidden, activation = activation, seed = seed)
h2o.deeplearning.3 <- function(..., hidden = c(500,500), activation = "RectifierWithDropout", epochs = 50, seed = 1)  h2o.deeplearning.wrapper(..., hidden = hidden, activation = activation, seed = seed)
h2o.deeplearning.4 <- function(..., hidden = c(500,500), activation = "Rectifier", epochs = 50, balance_classes = TRUE, seed = 1)  h2o.deeplearning.wrapper(..., hidden = hidden, activation = activation, balance_classes = balance_classes, seed = seed)
h2o.deeplearning.5 <- function(..., hidden = c(100,100,100), activation = "Rectifier", epochs = 50, seed = 1)  h2o.deeplearning.wrapper(..., hidden = hidden, activation = activation, seed = seed)
h2o.deeplearning.6 <- function(..., hidden = c(50,50), activation = "Rectifier", epochs = 50, seed = 1)  h2o.deeplearning.wrapper(..., hidden = hidden, activation = activation, seed = seed)
h2o.deeplearning.7 <- function(..., hidden = c(500,100), activation = "Rectifier", epochs = 50, seed = 1)  h2o.deeplearning.wrapper(..., hidden = hidden, activation = activation, seed = seed)

```


#### TUNED MODEL WRAPPERS (Only GBM)
```{r}
#GBM
h2o.gbm.tuned <- function(..., ntrees = 150, max_depth = 25, seed = 1, min_rows = 15, learn_rate = 0.05) h2o.gbm.wrapper(..., ntrees = ntrees, max_depth = max_depth, seed = seed)

```


#####LEARNERS
```{r}
learner <- c("h2o.glm.1",'h2o.glm.2',
             "h2o.randomForest.2", "h2o.randomForest.3", "h2o.randomForest.4",
             "h2o.gbm.1", "h2o.gbm.6", "h2o.gbm.8",
             "h2o.deeplearning.1", "h2o.deeplearning.6", "h2o.deeplearning.7")
```


###ENSEMBLE MODEL
```{r}
metalearner = 'h2o.deeplearning.meta' 
fit <- h2o.ensemble(x = x, y = y, 
                    training_frame = train1,
                    family = "gaussian", 
                    learner = learner, 
                    metalearner = metalearner,
                    cvControl = list(V = 5))
h2o.varimp(gbm)
```


#### PREDICTION
```{r}
# Generate predictions on the test set
pp <- predict(gamma.glm, test)
predictions = as.data.frame(pp$pred) 
#predictions$predict = exp(predictions$predict)
id = as.data.frame(id)
kaggle.sub = cbind(id,predictions)
colnames(kaggle.sub) = c('Id', 'SalePrice')
write.csv(kaggle.sub, file = 'ames_glm_5.csv', row.names = F, quote = F)
```


