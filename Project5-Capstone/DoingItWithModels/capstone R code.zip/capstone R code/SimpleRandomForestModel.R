train = read.csv("ryyy_train.csv",stringsAsFactors = FALSE)
test = read.csv("ryyy_test.csv",stringsAsFactors = FALSE)

SalePrice = train$SalePrice

# features = c("OverallQual", "GrLivArea","Neighborhood","ExterQual",
#                   "KitchenQual","BsmtQual","GarageArea","TotalBsmtSF",
#                   "GarageCars","FullBath","YearBuilt","GarageFinish",
#                   "HouseAge","RemodAge","GarageAge","Pool",
#                   "SeasonIdx","TrendIdx",
#                   "Mort30Lag1m","Mort15Lag1m","HPILag1s",
#                   "UnivAd","UnivNR","UnivItnl")

train= train[,-c(1,4,100)]
test = test[,-c(1,4)]
#features = c(names(confirmed),names(tentative))
features = selected

library(randomForest)

#rf <- randomForest(train.sl,SalePrice)
#features = names(train)

####################################
submission <- read.csv("sample_submission.csv",stringsAsFactors=FALSE)
for(variable in features){
  if(any(is.na(train[[variable]])))
  {
    print(paste(variable,"-",class(train[[variable]])))
    if(is.character(train[[variable]]))
    {
      train[[variable]][is.na(train[[variable]])] <- "Missing"
    }
    else
    {
      train[[variable]][is.na(train[[variable]])] <- mean(train[[variable]],na.rm=TRUE)
    }
  }
  if(any(is.na(test[[variable]])))
  {
    if(is.character(test[[variable]]))
    {
      test[[variable]][is.na(test[[variable]])] <- "Missing"
    }
    else
    {
      test[[variable]][is.na(test[[variable]])] <- mean(test[[variable]],na.rm=TRUE)
    }
  }
}

# Deal with factors
for(variable in features)
{
  if(is.character(train[[variable]])){
    levels <- sort(unique(c(train[[variable]],test[[variable]])))
    train[[variable]] <- factor(train[[variable]],levels=levels)
    test[[variable]] <- factor(test[[variable]],levels=levels)
  }
}

set.seed(0)
Response = log(SalePrice)
df.train = cbind(Response,train[features])
rf <- randomForest(Response~.,df.train,do.trace=TRUE)
importance(rf)
varImpPlot(rf)
p <- predict(rf,test)
submission$SalePrice <- exp(p)
write.csv(submission,file="submission4.csv",row.names=FALSE)
