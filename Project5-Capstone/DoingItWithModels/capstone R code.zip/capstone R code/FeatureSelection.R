library(caret)
library(data.table)
library(Boruta)
library(plyr)
library(dplyr)
library(pROC)

setwd("C:/Users/ricky/dropbox/bootcamp/capstone/")
train = read.csv("ryyy_train.csv",stringsAsFactors = FALSE)
test = read.csv("ryyy_test.csv",stringsAsFactors = FALSE)
SalePrice = train$SalePrice

train = train[,-c(1,4,103)]
test = test[,-c(1,4)]

features = names(train[,1:79])
candidate.features <- features
data.type <- sapply(candidate.features,function(x){class(train[[x]])})
table(data.type)

# deterimine data types
explanatory.attributes <- features
data.classes <- sapply(explanatory.attributes,function(x){class(train[[x]])})

# categorize data types in the data set?
unique.classes <- unique(data.classes)

attr.data.types <- lapply(unique.classes,function(x){names(data.classes[data.classes==x])})
names(attr.data.types) <- unique.classes

# pull out the response variable
response <- log(SalePrice)

# remove identifier and response variables
sample.df <- train[candidate.features]

# for numeric set missing values to -1 for purposes of the random forest run
for (x in attr.data.types$integer){
  sample.df[[x]][is.na(sample.df[[x]])] <- -1
}

for (x in attr.data.types$character){
  sample.df[[x]][is.na(sample.df[[x]])] <- "*MISSING*"
}

set.seed(0)
bor.results <- Boruta(sample.df,response,doTrace=2)
decision = bor.results$finalDecision
rejected = decision[which(decision == 'Rejected')]
confirmed = decision[which(decision == 'Confirmed')]
tentative = decision[which(decision == 'Tentative')]

boruta = data.frame(bor.results$ImpHistory)

write.csv(boruta,"boruta_0914new.csv")

selected = names(c(confirmed, tentative))

# > selected
# [1] "MSSubClass"    "MSZoning"      "LotFrontage"  
# [4] "LotArea"       "LotShape"      "Neighborhood" 
# [7] "BldgType"      "HouseStyle"    "OverallQual"  
# [10] "OverallCond"   "YearBuilt"     "YearRemodAdd" 
# [13] "RoofStyle"     "Exterior1st"   "Exterior2nd"  
# [16] "MasVnrType"    "MasVnrArea"    "ExterQual"    
# [19] "Foundation"    "BsmtQual"      "BsmtCond"     
# [22] "BsmtExposure"  "BsmtFinType1"  "BsmtFinSF1"   
# [25] "BsmtFinType2"  "BsmtUnfSF"     "TotalBsmtSF"  
# [28] "HeatingQC"     "CentralAir"    "X1stFlrSF"    
# [31] "X2ndFlrSF"     "GrLivArea"     "BsmtFullBath" 
# [34] "FullBath"      "HalfBath"      "BedroomAbvGr" 
# [37] "KitchenAbvGr"  "KitchenQual"   "TotRmsAbvGrd" 
# [40] "Fireplaces"    "FireplaceQu"   "GarageType"   
# [43] "GarageYrBlt"   "GarageFinish"  "GarageCars"   
# [46] "GarageArea"    "GarageQual"    "GarageCond"   
# [49] "PavedDrive"    "WoodDeckSF"    "OpenPorchSF"  
# [52] "ScreenPorch"   "HouseAge"      "RemodAge"     
# [55] "GarageAge"     "Basement"      "Fireplace"    
# [58] "Garage"        "LandContour"   "LandSlope"    
# [61] "Condition1"    "Electrical"    "Functional"   
# [64] "Fence"         "SaleCondition" "AccStreet"    
# [67] "Fenc"          "NewHome"       "SaleCondNorm" 
# [70] "TsIdx"        
# > names(confirmed)
# [1] "MSSubClass"   "MSZoning"     "LotFrontage" 
# [4] "LotArea"      "LotShape"     "Neighborhood"
# [7] "BldgType"     "HouseStyle"   "OverallQual" 
# [10] "OverallCond"  "YearBuilt"    "YearRemodAdd"
# [13] "RoofStyle"    "Exterior1st"  "Exterior2nd" 
# [16] "MasVnrType"   "MasVnrArea"   "ExterQual"   
# [19] "Foundation"   "BsmtQual"     "BsmtCond"    
# [22] "BsmtExposure" "BsmtFinType1" "BsmtFinSF1"  
# [25] "BsmtFinType2" "BsmtUnfSF"    "TotalBsmtSF" 
# [28] "HeatingQC"    "CentralAir"   "X1stFlrSF"   
# [31] "X2ndFlrSF"    "GrLivArea"    "BsmtFullBath"
# [34] "FullBath"     "HalfBath"     "BedroomAbvGr"
# [37] "KitchenAbvGr" "KitchenQual"  "TotRmsAbvGrd"
# [40] "Fireplaces"   "FireplaceQu"  "GarageType"  
# [43] "GarageYrBlt"  "GarageFinish" "GarageCars"  
# [46] "GarageArea"   "GarageQual"   "GarageCond"  
# [49] "PavedDrive"   "WoodDeckSF"   "OpenPorchSF" 
# [52] "ScreenPorch"  "HouseAge"     "RemodAge"    
# [55] "GarageAge"    "Basement"     "Fireplace"   
# [58] "Garage"      
# > names(tentative)
# [1] "LandContour"   "LandSlope"     "Condition1"   
# [4] "Electrical"    "Functional"    "Fence"        
# [7] "SaleCondition" "AccStreet"     "Fenc"         
# [10] "NewHome"       "SaleCondNorm"  "TsIdx"        
# > 



features_select = 
c("MSSubClass",    "MSZoning",      "LotFrontage",  
  "LotArea",       "LotShape",      "Neighborhood", 
  "BldgType",      "HouseStyle",    "OverallQual",  
  "OverallCond",   "YearBuilt",     "YearRemodAdd", 
  "RoofStyle",     "Exterior1st",   "Exterior2nd",  
  "MasVnrType",    "MasVnrArea",    "ExterQual",    
  "Foundation",    "BsmtQual",      "BsmtCond",     
  "BsmtExposure",  "BsmtFinType1",  "BsmtFinSF1",   
  "BsmtFinType2",  "BsmtUnfSF",     "TotalBsmtSF",  
  "HeatingQC",     "CentralAir",    "X1stFlrSF",    
  "X2ndFlrSF",     "GrLivArea",     "BsmtFullBath", 
  "FullBath",      "HalfBath",      "BedroomAbvGr", 
  "KitchenAbvGr",  "KitchenQual",   "TotRmsAbvGrd", 
  "Fireplaces",    "FireplaceQu",   "GarageType",   
  "GarageYrBlt",   "GarageFinish",  "GarageCars",   
  "GarageArea",    "GarageQual",    "GarageCond",   
  "PavedDrive",    "WoodDeckSF",    "OpenPorchSF",  
  "ScreenPorch",   "HouseAge",      "RemodAge",     
  "GarageAge",     "Basement",      "Fireplace",    
  "Garage",        "LandContour",   "LandSlope",    
  "Condition1",    "Electrical",    "Functional",   
  "Fence",         "SaleCondition", "AccStreet",    
  "Fenc",          "NewHome",       "SaleCondNorm", 
  "TsIdx")   
  
  
  
  



